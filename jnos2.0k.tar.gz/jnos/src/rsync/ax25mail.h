int ax250 __ARGS((int argc,char *argv[],void *p));
int ax25start __ARGS((int argc,char *argv[],void *p));
/* int dogateway __ARGS((int argc,char *argv[],void *p)); */
