  
JNOS v1.10c SOURCE CODE. DISTRIBUTED AS IS, NO WARRANTY OF ANY KIND!
  
Please read the README.NOW file in this archive to see what mods have
been made. Info about compilers etc. is also in there...
  
Goodluck and 73
  
Johan, wg7j
  
