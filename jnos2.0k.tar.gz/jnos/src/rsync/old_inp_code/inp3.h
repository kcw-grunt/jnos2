/*
 * Function prototypes for new INP3 functionality
 *
 * September 22, 2005, by Maiko Langelaar / VE4KLM
 */

#if defined (NETROM) && defined (INP3)

#include "mbuf.h"
#include "netrom.h"

#ifndef OPTIONAL
#define OPTIONAL
#endif

/* Definitions for INP3 routines */

#define INPVERSION "007"
#define L3RTT_INTERVAL 5
/* #define RIF_INTERVAL 24*60 */
#define RIF_INTERVAL 24
#define L3RTT_MTU 200
#define TT_HORIZON 60000
#define	MAX_RIPNEG 15
#define	NR_INFO 0x05

#define ttlimit(tt) ((tt) > TT_HORIZON ? TT_HORIZON : (tt))
#define qual2rtt(qual) ((qual) ? (ttlimit((256-(qual))*20)) : TT_HORIZON)
#define hopsmin(hops) ((hops)<1 ? 1 : (hops))
#define qual2hops(qual) ((256-(qual))/8+1)

/* Define INP3 State constants */

enum {
	NR_INP_STATE_0,		/* Not recognized as an INP neighbour */
	NR_INP_STATE_RTT,	/* Got RTT back, but no RIPs yet... */
	NR_INP_STATE_INP,	/* Recognized as a full INP neighbour */
};

/* File : NRR.C */

extern int inp3_is_this_nrr (unsigned char *);
extern int inp3_proc_nrr (struct nr3hdr*, struct mbuf**);

/* File : L3RTT.C */

extern int inp3_is_this_l3rtt (char*);
extern int inp3_proc_l3rtt (char*, struct mbuf*, struct ax25_cb*);

/* File : INP3RTNS.C */

extern int infotype (unsigned int, unsigned int);
extern int inp3_l3rtt_tx (struct nrnbr_tab*, struct iface*);
extern int inp3_rif_tx (struct nrnbr_tab*, int);
extern int inp3_rif_rx (struct mbuf*, struct ax25_cb*);
extern void inp3_ltt_update (int, int);
extern void inp3_route_neg (struct nrnbr_tab*);
extern int rtt2qual (int, int);

extern void inp3_nodes_neg (struct nrroute_tab *neg_node[], int, struct nrnbr_tab*);
#endif
