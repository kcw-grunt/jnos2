/*
 * New INP support, continuing from work I started 6 years ago
 *
 * Note : use 'set ts=4' if using the VI(M) editor ...
 *
 * August 2011, by Maiko Langelaar (VE4KLM)
 *
 * By end of 20Aug2011, I have L3RTT going both ways, no more crashing,
 * turns out the nrdump code that displays the RIF stuff is buggy, need
 * to fix it, commented out for now. Next step is to do something with
 * the RTT value, right now messages are just passed, nothing done with
 * actual data.
 *
 * 21Aug2011, Maiko (VE4KLM), new inp_rif_recv() seems to work nicely,
 * just have to use the data now and adjust node tables, and so on.
 *
 * 22Aug2011, Maiko (VE4KLM), basic update nrnbr table with rtt, and
 * include INP stuff in the netrom.h structures, donrneighbour now shows
 * the INP flag and rtt value, cleaned up formatting a bit (with Irtt).
 *
 * Interesting note, my ALIAS for my Xrouter partner is not defined, so I
 * think what this means is that if INP is active, the remote side no longer
 * uses conventional netrom broadcasts to send out info, it's all RIFS now,
 * should confirm that via the traces, but that's what it looks like. If you
 * think about it, it would be a big waste of bandwidth to have both systems
 * running. See the next paragraph below (post note) which confirms this.
 *
 * 24Aug2011, Maiko, Seeing alot of 'not in our node table' log entries, and
 * I don't see any NODES broadcasts coming from my Xrouter neighbour, who is
 * actually VE2PKT-4 (Jean) - guess that means I'll have to add nodes as well
 * for incoming RIFS - regular netrom broadcasts do not seem to be used when
 * running INP mode (if I can word it that way). That seems to be the case.
 * Also I have noticed later on that the ALIAS was filled in for my Xrouter
 * neighbour (running INP) yet I see no netrom broadcast from him. That is
 * because it was filled in by other partners I have who are running regular
 * netrom systems. That explains the missing ALIAS part. Anyways, bottom line
 * is I have to add nodes if they are not in my tables when RIF comes in, as
 * well as add routes (also seeing alot of 'no route via this neighbour).
 *
 * Oops saw a netrom broadcast after 1 hour (that seems a long time), so maybe
 * because I have yet to send him any RIFs he will label me as non-INP and do
 * the broadcasts. That's all I can deduct right now, and there are still alot
 * of missing route or missing node in our table messages - anyways, enough !
 *
 * 23Aug2011, I now process incoming RIF/RIP entries and manipulate the netrom
 * memory structures, so technically I think this part is done, incoming RIF
 * messages should now auto update the nodes table with new quality values,
 * hops, and transport times. The only outstanding thing I have to work on
 * with regard to incoming RIF messages now is NEGATIVE node information,
 * something I need to first better educate myself on before I pursue it.
 */

#include <ctype.h>

#include "global.h"

#if defined (NETROM) && defined (INP2011)

#include "ax25.h"

#include <sys/time.h>

#include "mbuf.h"
#include "netrom.h"

#ifndef OPTIONAL
#define OPTIONAL
#endif

#define L3RTT_INTERVAL	300000	/* 5 minutes (5 x 60 x 1000) */
#define	TT_HORIZON 6000
#define	NR_INFO 0x05

/* Define INP state constants */

enum {
	NR_INP_STATE_0,		/* Not recognized as an INP neighbour */
	NR_INP_STATE_RTT,	/* Got RTT back, but no RIPs yet... */
	NR_INP_STATE_INP,	/* Recognized as a full INP neighbour */
};

struct timer INPtimer;

static char L3RTTcall[AXALEN] = {
    'L' << 1, '3' << 1, 'R' << 1, 'T' << 1, 'T' << 1, ' ' << 1, '0' << 1
};

static int INP_active = 0;

extern char Nralias[];

extern struct nr_bind *find_bind (struct nr_bind*, struct nrnbr_tab*);

/* 23Aug2011, Maiko (VE4KLM), needed to process incoming RIP, from orig code */

static int rtt2qual (int rtt, int hops)
{
	int qual;

	if (rtt >= TT_HORIZON)
		return 0;

	if (hops >= 255)
		return 0;
	
	qual = 254 - (rtt / 20);

	if (qual > 256 - hops)
		qual = 254 - hops;

	if (qual < 1)
		qual = 0;

	return qual;
}

/* 21Aug2011, Maiko (VE4KLM), new version of RIF/RIP receive function,
 * by evening it seems to be working quite nicely, just have to adjust
 * a few items (ie, how things are logged). Next step is to use the data
 * contained in the RIF/RIP entries to adjust node tables, etc ...
 *
 * 23Aug2011, Maiko (VE4KLM), basic update of node tables from RIF frames
 * is technically complete, just need to look at negative node stuff now,
 * which I am not familiar with yet, need to read up on that first. I've
 * decided for now to just find NR neighbour ONCE (see below), see how
 * stable INP code is and then make a decision further down the road.
 */

#define	NBNBR_BEFORE_RIP_LOOP	/* Read nbnbr only once, not 4 each RIP */

int inp_rif_recv (struct mbuf *bp, struct ax25_cb *ax25)
{
	unsigned char nr_data[300], *dptr;	/* pullup & unsigned vars, grrr */

	int quality, transportime, hops, dlen;
	char nodecall[AXALEN], tmp[AXBUF];
	int opt_field_len, opt_field_type;
	struct nrroute_tab *nr_node;
	struct nrnbr_tab *nr_neigh;
	char logdata[100], *lptr;
	struct nr_bind *nrbp;

	char alias[AXALEN+5]; /* 24Aug2011, Maiko, Why are they using AXALEN ? */

	dlen = len_p (bp) - 1;	/* skip 0xff */

	dptr = nr_data + 1;		/* skip 0xff */

 	/* read all of it, 300 is just a max */
	pullup (&bp, (unsigned char*)nr_data, 300);

#ifdef	NBNBR_BEFORE_RIP_LOOP
	if ((nr_neigh = find_nrnbr (ax25->remote, ax25->iface)) == NULLNTAB)
	{
		if (Nr_debug)
		{
			log (-1, "add neighbor [%s] port [%s]",
				pax25 (tmp, ax25->remote), ax25->iface->name);
		}

		/* 24Aug2011, Maiko (VE4KLM), add neighbor if not present */
		nr_neigh = add_nrnbr (ax25->remote, ax25->iface);
	}
#endif

	while (dlen > 0)
	{
		memcpy (nodecall, dptr, AXALEN);
		dptr += AXALEN;
		hops = *dptr++;
		transportime = (*dptr++ << 8);
		transportime += *dptr++;
		dlen = dlen - AXALEN - 3;

		if (Nr_debug)
		{
			lptr = logdata;	/* important */

			lptr += sprintf (lptr, "[%s] hops [%d] tt [%d]",
				pax25 (tmp, nodecall), hops, transportime);
		}

		while (1)
		{
			opt_field_len = *dptr++;
			dlen--;

			if (!opt_field_len)
				break;

			opt_field_type = *dptr++;
			dlen--;

			opt_field_len -= 2;

			switch (opt_field_type)
			{
				case 0:
					if (Nr_debug)
					{
						int tlen = opt_field_len;

						char *aptr = alias, *tptr = dptr;
				/*
				 * 21Aug2011, Maiko, noticing corrupt alias values from time
				 * to time, which locks up any 'tail -f' of log file, better
				 * screen for non printables, and just replace those values
				 * with '?' instead to prevent this from happening - done.
				 * 24Aug2011, Maiko, need alias for route add later on.
				 */
						while (tlen > 0)
						{
							if (isprint (*tptr))
								*aptr = *tptr;
							else
								*aptr = '?';

							tptr++;
							aptr++;
							tlen--;
						}

						*aptr = 0;

						lptr += sprintf (lptr, " alias [%s]", alias);
					}
					break;

				case 1:
					if (Nr_debug)
					{
						lptr += sprintf (lptr, " ip [%.15s]",
							inet_ntoa ((int32)(*dptr)));
					}
					break;

				default:
					if (Nr_debug)
						log (-1, "field type (%d) unknown", opt_field_type);
					break;
			}

			dptr += opt_field_len;

			dlen -= opt_field_len;
		}

		if (Nr_debug)
			log (-1, "rif %s", logdata);
		/*
		 * 23Aug2011, Maiko, Now comes the fun part, processing the info
		 * contained in each RIP entry and manipulating TT, RTT, and other
 		 * information kept in the various netrom memory structures.
		 *
		 * To make matters a bit more of a pain, I don't like the idea I have
		 * to find my neighbour for EACH SINGLE RIP, why not just once at the
		 * top of this function (once per RIF) ? This is because there is no
		 * clear mechanism to tell me if 'nr_neigh' pointer is valid or not,
		 * if for some reason the neighbour is deleted from memory during the
		 * processing of one individual RIP. Mind you, the NOS sheduling alg
		 * may wipe out this concern, but for now do it each time (or not) ?
		 *
		 * 23Aug2011, Technically I think this part is done, any incoming
		 * RIF values should now auto update the nodes table with new quality
		 * values, hops, and transport times. The only outstanding thing I
		 * have to work on (ie, add) now is NEGATIVE node information, and
		 * that is something I need to first better educate myself on.
		 */

#ifndef	NBNBR_BEFORE_RIP_LOOP
		if ((nr_neigh = find_nrnbr (ax25->remote, ax25->iface)) == NULLNTAB)
		{
			if (Nr_debug)
			{
				log (-1, "neighbor [%s] port [%s] seems to have disappeared",
					pax25 (tmp, ax25->remote), ax25->iface->name);
			}

			/* 24Aug2011, Maiko (VE4KLM), add neighbor if not present */
			nr_neigh = add_nrnbr (ax25->remote, ax25->iface);
		}
#endif
		nr_neigh->inp_state = NR_INP_STATE_INP;	/* rifs means active INP */

		/* are we over the horizon ? */

		if (transportime + nr_neigh->rtt > TT_HORIZON || hops == 255)
			transportime = TT_HORIZON;

		quality = rtt2qual (nr_neigh->rtt + transportime, hops);

		/* get the node entry for this particular RIP record */
		if ((nr_node = find_nrroute (nodecall)) == NULLNRRTAB)
		{
			if (Nr_debug)
			{
				log (-1, "add node [%s] to our node table",
					pax25 (tmp, nodecall));
			}

			nr_node = add_nrroute (alias, nodecall); /* new func in nr3.c */

			/*
			 * 24Aug, Maiko (VE4KLM), If not in our tables, then add it
			 *
			 * alot of call over head just to do this, so let's just take
			 * the calls within nr_routeadd() that we need and do the rest
			 * here, instead of making all these (what would be CPU intense)
			 * unnecessary function calls - nr_routeadd() is bloated :(
			 *
			nr_routeadd (alias, nodecall, ax25->iface,
				quality, nr_neigh->call, 0, 0);

			nr_node = find_nrroute (nodecall);
			 *
			 */
		}

	 	/* find the route that binds the node to current neighbour */
		if ((nrbp = find_bind (nr_node->routes, nr_neigh)) == NULLNRBIND)
		{
			if (Nr_debug)
			{
				log (-1, "add binding to node [%s] via this neighbour",
					pax25 (tmp, nodecall));
			}

			/* 24Aug2011, Maiko, new function in nr3.c */
			nrbp = add_binding (nr_neigh, nr_node);
		}

		if (Nr_debug)
		{
			log (-1, "update (old/new) tt %d/%d hops %d/%d qual %d/%d",
				nrbp->tt, transportime, nrbp->hops, hops,
					nrbp->quality, quality);
		}

		nrbp->tt = transportime;
		nrbp->hops = hops;
		nrbp->quality = quality;
	}

	return 1;
}

/* 18/19 August 2011 */

int inp_l3rtt (char *dest)
{
	/* 21Aug2011, Maiko, If INP timer is off, don't process incoming L3RTT */
	return (INP_active && addreq (L3RTTcall, dest));
}

/*
 * 18/19Aug2011, Maiko, revamped from the original 2005 version,
 *
 * 21Aug2011, Maiko, payload size tune up, next step - use RTT value.
 *
 * 22Aug2011, Maiko, Let's do this netrom table by table, so first let's
 * get all the changes made that utilized the nrnbr_tab structure. The 2nd
 * parameter is no longer 'remote', it is now 'struct ax25_cb', since I want
 * both remote and iface now, might as well just stick to one argument.
 *
 */

int inp_l3rtt_recv (char *src, struct ax25_cb *iaxp, struct mbuf *bp)
{
	struct nrnbr_tab *nr_neigh = NULL;	/* 22Aug2011, Maiko */

	char tmp[AXBUF], nr_data[100], *dptr;
	struct timeval tv, tvret;
	struct timezone tz;
	long rtt;

	pullup (&bp, nr_data, 100); /* read all of it, 80 is just a max */

	dptr = nr_data + 5;	/* skip dummy and 0x05 identifier */

	while (*dptr == 0x20) dptr++;
	tvret.tv_sec = strtoul (dptr, (char**)(&dptr), 0);
	while (*dptr == 0x20) dptr++;
	strtoul (dptr, (char**)(&dptr), 0);
	while (*dptr == 0x20) dptr++;
	strtoul (dptr, (char**)(&dptr), 0);
	while (*dptr == 0x20) dptr++;
	tvret.tv_usec = strtoul (dptr, (char**)(&dptr), 0);

	gettimeofday (&tv, &tz);
/*
	log (-1, "incoming %ld %ld current %ld %ld",
		tvret.tv_sec, tvret.tv_usec, tv.tv_sec, tv.tv_usec);
*/
	rtt = (long)(((tv.tv_sec - tvret.tv_sec) * 1000
			+ (tv.tv_usec + 10000) / 1000) / 20);

	if (!rtt) rtt = 1;

	if (Nr_debug)
	{
		log (-1, "l3rtt response from [%s] rtt [%ld]",
			pax25 (tmp, iaxp->remote), rtt);
	}

	/* 22Aug2011, Maiko, Update the netrom tables, lookup neighbour first */

	if ((nr_neigh = find_nrnbr (iaxp->remote, iaxp->iface)) == NULLNTAB)
	{
		log (-1, "l3rtt recv, remote [%s] iface [%s] - no neighbour entry",
			pax25 (tmp, iaxp->remote), iaxp->iface->name);

		return 0;
	}

	/* is this a new interlink ? give it a higher RTT */

	if (nr_neigh->inp_state == NR_INP_STATE_0)
	{
		nr_neigh->inp_state = NR_INP_STATE_RTT;

		nr_neigh->rtt = rtt + 10;

		log (-1, "neighbour [%s] interlink (l3rtt)",
			pax25 (tmp, nr_neigh->call));

		/* inp3_rif_tx (nr_neigh, 1); */
	}

	/* Smooth RTT value */

	rtt = nr_neigh->rtt = (nr_neigh->rtt + rtt) / 2;

	if (Nr_debug)
	{
		log (-1, "neighbour [%s] smoothed rtt [%d]",
			pax25 (tmp, nr_neigh->call), rtt);
	}

	if (rtt >= TT_HORIZON)
	{
		log (-1, "is now over (l3rtt) horizon");

		/* inp3_route_neg (nr_neigh);
			nr_neigh_put (nr_neigh);
			dev_put (dev);
		 */
			return 0;
	}

	/* 22Aug2011, Maiko, end (ongoing) USE l3rtt.c code from years ago */

	return 1;
}

/*
 * 19/20 August 2011 - Maiko, works, BUT crashing after the response comes
 * back. After a bit of observation, I have to conclude that it's actually
 * some thing in the trace code (likely nr_dump) that is doing this. I've
 * had the trace shut off for several hours and it's perfectly fine now.
 *
 * 21Aug2001, Maiko, Think I'm done with this for now, payload size tuned
 * up nicely, and it seems to be working quite well now.
 */

int inp_l3rtt_tx (struct nrnbr_tab *nr_neigh, char *ifcname)
{
	struct timezone tz;
	struct timeval tv;
	struct mbuf *hbp;
	struct nrroute_tab *rp;
	struct nr3hdr n3hdr;
	struct mbuf *n3b;
	char tmp[AXBUF];
	char *rtt_data;

	if (Nr_debug)
	{
		log (-1, "l3rtt request to [%s] on port [%s]",
			pax25 (tmp, nr_neigh->call), ifcname);
	}

	/* get the netrom level 3 data formatted first */

	if ((hbp = alloc_mbuf (69)) == NULLBUF)
	{
		log (-1, "inp_l3rtt_tx - no memory");
		return 0;
	}

	hbp->cnt = 69;	/* 21Aug2011, Maiko (VE4KLM), fine tune the size */

	rtt_data = hbp->data;

	*rtt_data++ = 0x00;
	*rtt_data++ = 0x00;
	*rtt_data++ = 0x00;
	*rtt_data++ = 0x00;

	*rtt_data++ = NR_INFO;

	/* do_gettimeofday (&tv); */
	gettimeofday (&tv, &tz);

	/*
	 * 21Aug2011, Maiko (VE4KLM), The INP specification says the text portion
	 * of L3RTT frames are implementation specific (which makes sense now that
	 * I see the trace data), the remote system simply has to reflect it back
	 * to the sender unchanged, so lets keep bandwith usage to a minimum, and
	 * just send what we need. The JNOS version is not required, but it could
	 * come in useful from a troubleshooting point of view.
	 *
	 * 22Aug2011, Maiko (VE4KLM), Now that nrnbr is updated, we can now use
	 * the values from there and not the hardcoded values of 60 I used.
	 */
	rtt_data += sprintf (rtt_data, "%10d %10d %10d %10d JNOS 2.0i $M%d $N",
		(int)tv.tv_sec, /* 60 */ nr_neigh->rtt, /* 60 */ nr_neigh->rtt,
			(int)tv.tv_usec, TT_HORIZON);

    *rtt_data = 0x0d;

	/* now setup the netrom level 3 header */

	memcpy (n3hdr.dest, L3RTTcall, AXALEN);

	n3hdr.ttl = 3;	/* nr routing decrements it, it will go out as a 2 */

	if ((rp = find_nrroute (nr_neigh->call)) == NULLNRRTAB)
	{
		log (-1, "no route to [%s] on port [%s]",
			pax25 (tmp, nr_neigh->call), ifcname);

		return 0;
	}

	/* we are originating this, so iaxp is set to NULLAX25 */
   if (!nr_finally_route (hbp, rp, NULLAX25, &n3hdr))
		free_p (n3b);

	return 1;
}

/* 20Aug2011, Maiko */

void doINPtick()
{
#ifdef	TEST
	struct nrnbr_tab nr_neigh;

    setcall (nr_neigh.call, "ve2pkt-4");

	inp_l3rtt_tx (&nr_neigh, "que");
#else
	struct nrnbr_tab *nr_neigh;

	int chain;

	for (chain = 0; chain < NRNUMCHAINS; chain++)
	{
		nr_neigh = Nrnbr_tab[chain];

		while (nr_neigh != NULL)
		{
			inp_l3rtt_tx (nr_neigh, nr_neigh->iface->name);

			nr_neigh = nr_neigh->next;
		}
	}
#endif
  
    /* Restart timer */
    start_timer (&INPtimer) ;
}

/* 20Aug2011, Maiko */

/* Set l3rtt interval (same structure function as donodetimer) */
int doINPtimer (int argc, char **argv, void *p)
{
	log (-1, "INP scheduler is active");

	INP_active = 1;	/* 21Aug2011, Maiko, flag to tell nr3.c to accept L3RTT */ 

    stop_timer (&INPtimer) ;	/* in case it's already running */

    INPtimer.func = (void (*)(void*))doINPtick;	/* what to call on timeout */

    INPtimer.arg = NULLCHAR;	/* dummy value */

    set_timer (&INPtimer, L3RTT_INTERVAL);	/* atoi(argv[1])*1000); */

    start_timer (&INPtimer);

    return 0;
}

#endif

