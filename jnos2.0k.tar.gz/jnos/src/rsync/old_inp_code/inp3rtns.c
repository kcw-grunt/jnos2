
/*
 * 14Sep2005, Maiko Langelaar (VE4KLM), My attempt to add INP3 to JNOS !
 *
 * Using a combination of code taken from other modules I have written,
 * and from that point on, this is very much based on ideas taken from
 * the 2.6.4 kernal patch provided on the internet by PE1RXQ.
 *
 * End of 14Sep2005 - inp3_rif () more or less finished
 * need to port/write inp3_l3rtt () function still
 * actually compiles, good progress perhaps !!!
 *
 * End of 15Sep2005 - inp3_l3rtt () and inp3_l3rtt_tx () more or less
 * written, compiles, need to figure out how to and what device to send
 * out too, porting inp3_l3rtt_rx () ...
 *
 */

#include "global.h"

#if defined (NETROM) && defined (INP3)

#include "timer.h"
#include "ax25.h"

#include "netrom.h"
#include "iface.h"

#include <sys/time.h>

#include <ctype.h>

#include "inp3.h"

extern struct nr_bind *find_best (struct nr_bind*, int);
extern struct nr_bind *find_bind (struct nr_bind*, struct nrnbr_tab*);

#ifdef	DONT_COMPILE

/* Changed my mind - this is not very portable and very confusing */

/*
 * I've never used LIST ENTRY macros before in my 10+ years of C programming,
 * so this is new to me - looks useful - The hlist.h that I have distributed
 * with this software was cut and paste from an example I found on the Inet,
 * specifically from the URL below (since my linux had no hlist.h included).
 *
 * http://svn.drbd.org/drbd/branches/drbd-0.7/drbd/hlist.h
 */
#include "hlist.h"

#endif

#ifndef	OPTIONAL
#define OPTIONAL
#endif

extern char Nralias[ALEN+1];

static struct timer inp3_l3rtt_tm;

int infotype (unsigned int ltt, unsigned int tt)
{
	if (tt >= TT_HORIZON)
	{
		if (ltt != TT_HORIZON)
			return -1;
		else
			return 0;
	}

	if (tt > ltt)
		return -1;

	if ((tt * 5 < ltt * 4) && (ltt - tt > 10))
		return 1;

	return 0;
}

int rtt2qual (int rtt, int hops)
{
	int qual;

	if (rtt >= TT_HORIZON)
		return 0;

	if (hops >= 255)
		return 0;
	
	qual = 254 - (rtt / 20);

	if (qual > 256 - hops)
		qual = 254 - hops;

	if (qual < 1)
		qual = 0;

	return qual;
}

/*
 * start of PE1RXQ code - added September 22, 2005, and begin
 * modifying it to 'fit' the NOS code structure
 */

/* 14Sep2005, Maiko, May actually get the inp3_rif () completed !!! */
/* 20Sep2005, Maiko, Function complete, testing real time now !!! */
/* 16Dec2005, Maiko - Function review - looks okay ! */
static void rif_tx (struct nrnbr_tab *nr_neigh, struct mbuf *hptr)
{
	struct nrroute_tab *rp;
	struct nr_bind *bindp;
	struct nrnbr_tab *np;
	struct iface *iface;
	struct ax25_cb *axp;

	char tmp[AXBUF];

	if (Nr_debug)
	{
		log (-1, "transmit RIF neighbor [%s] state %d",
			pax25 (tmp, nr_neigh->call), nr_neigh->inp_state);
	}

	/* only to INP3 nodes */
	if (nr_neigh->inp_state == NR_INP_STATE_0)
	{
		free_p (hptr);
		return;
	}

	np = nr_neigh;

	iface = np->iface;

	if ((axp = find_ax25 (Nr_iface->hwaddr, np->call, iface)) == NULLAX25 ||
	(axp->state != LAPB_CONNECTED && axp->state != LAPB_RECOVERY))
	{
		if (Nr_debug)
			log (-1, "open or reopen a connection to neighbour");

        axp = open_ax25 (iface, Nr_iface->hwaddr, np->call, AX_ACTIVE, 0,
				s_arcall, s_atcall, s_ascall, -1);

        if (axp == NULLAX25)
		{
			log (-1, "unable to open an AX25 session to neighbour");
            free_p (hptr);
            return;
        }
    }

    send_ax25 (axp, hptr, -1);	/* pass off to the ax25 code */
}

/*
 * 14Sep2005, This function is essentially written, already have figured
 * out mapping - their nr_node and nr_route structures to ours. Figured
 * out the list entry macro as well. DONE !!!
 *
 * 16Dec2005, Maiko, Function review - looks okay !
 */
void inp3_ltt_update (int all, int neg)
{
	struct nrroute_tab *nr_node;
	struct nr_bind *nrbp;
	unsigned int tt;
	int chain;

	lock_nrroute ();	/* 02Nov2005, Maiko, Start locking nrroute tab */

	for (chain = 0; chain < NRNUMCHAINS; chain++)
	{
		nr_node = Nrroute_tab[chain];

		while (nr_node != NULL)
		{
			/*
			 * assumption is that with Linux code, routes[0] is the BEST
			 * route of the lot (ie, the best quality). In NOS, we use the
			 * find_best () function instead, since we link list the bind
			 * entries - my *little* oversite discovered on 01Nov2005.
			 */
			if ((nrbp = find_best (nr_node->routes, 0)) != NULLNRBIND)
			{
				if ((nrbp->via)->inp_state == NR_INP_STATE_INP)
					tt = nrbp->tt + (nrbp->via)->rtt;
				else
					tt = qual2rtt (nrbp->quality);

				if ((ttlimit (tt) > nr_node->ltt) ||
					(!neg && infotype (nr_node->ltt, tt)) || all)
				{
					nr_node->ltt = ttlimit (tt);
				}
			}

			nr_node = nr_node->next;
		}
	}

	unlock_nrroute ();	/* 02Nov2005, Maiko, Should start using locks */
}


/*
 * Sends negative info about neg_nodes to neigh_list.
 * End of 22 Sept - This one too is more or less finished !
 * 02Nov2005, Maiko, Far from it, need to convert Linux Kernel
 * route array to our route (bind) link list (challenging).
 *
 * 17Dec2005, Maiko, Function review - looks okay, BUT need to
 * put in code to get 2nd and 3rd best routes, so this is not
 * complete, but should work better than nothing - I need to
 * get it completed - see the TODO tags in logfile for now,
 * also need to complete part that removes negative routes
 * from the routes list of particular node. See TODO also.
 */
void inp3_nodes_neg (struct nrroute_tab *neg_node[],
		int neg_nodes, struct nrnbr_tab *origin_neigh)
{
	/*
 	 * looks to me that their 'nr_node' maps to our 'nrroute_tab',
	 * and their 'nr_route' maps to our 'nr_bind' structure
	 * and their 'nr_neigh' maps to our 'nrnbr_tab' struct.
	 * Mid September, porting to NOS code structure
	 * Maiko Langelaar / VE4KLM
	 */

	struct nr_bind *negbp, *negbp2;
	struct nrnbr_tab *nr_neigh;
	unsigned int route, tt;
	int chain, i, hops, nr;
	struct mbuf *dbp;

	for (chain = 0; chain < NRNUMCHAINS; chain++)
	{
		nr_neigh = Nrnbr_tab[chain];

		while (nr_neigh != NULL)
		{
			struct mbuf *hbp, *dbp;
			int len, ripcount = 0;
			unsigned char *rip;
			int calchopstt;

			if ((hbp = alloc_mbuf (2)) == NULLBUF)
				return;

			hbp->cnt = 2;

			hbp->data[0] = PID_NETROM;
			hbp->data[1] = NR3NODESIG;

			for (i = 0; i < neg_nodes; i++)
			{
				if (neg_node[i]->ltt >= TT_HORIZON)
					continue;

				if ((negbp = find_best (neg_node[i]->routes, 0)) == NULLNRBIND)
					continue;

				calchopstt = 0;

				if ((negbp->via)->rtt + negbp->tt < TT_HORIZON &&
					negbp->via != nr_neigh)
				{
						calchopstt = 1;
				}
				else
				{
					if (neg_node[i]->num_routes == 2)
					{
						log (-1, "inp3_nodes_neg - TODO - is next best route neighbour");
					}
					else
					{
						log (-1, "inp3_nodes_neg - TODO - calculate hops and tt");
					}
				}

				if (calchopstt)
				{
					if ((negbp->via)->inp_state == NR_INP_STATE_INP)
					{
						hops = negbp->hops;

						tt = negbp->tt + (negbp->via)->rtt;
					}
					else
					{
						hops = qual2hops (negbp->quality);

						tt = qual2rtt (negbp->quality);
					}
				}
				else
				{
					hops = 254;
					tt = TT_HORIZON;
				}

				if ((tt >= TT_HORIZON && origin_neigh == nr_neigh) ||
					tt <= neg_node[i]->ltt)
				{
					continue;
				}

				len = AXALEN + 4;	/* include EOP */

				if ((dbp = alloc_mbuf (len)) == NULLBUF)
					return;

				dbp->cnt = len;
				rip = dbp->data;

				memcpy (rip, &neg_node[i]->call, AXALEN);
				rip += AXALEN;

				*rip++ = hopsmin (hops) + 1;
				*rip++ = ttlimit (tt) / 256;
				*rip++ = ttlimit (tt) & 0xff;

				*rip++ = 0;	/* no alias for this I guess */

				append (&hbp, dbp);	/* append to chain */

				ripcount++;
			}

			if (ripcount)
				rif_tx (nr_neigh, hbp);
			else
				free_p (hbp);

			nr_neigh = nr_neigh->next;
		}
	}

#ifndef CONTINUE_WHAT_DOES_THIS_DO

	log (-1, "inp3_nodes_neg - TODO - remove negative route from node");

#else

	for (i = 0; i < neg_nodes; i++)
	{
		for (nr = (int)(neg_node[i]->num_routes - 1); nr >= 0; nr--)
		{
			if (neg_node[i]->routes[nr].via->rtt +
				neg_node[i]->routes[nr].tt >= TT_HORIZON)
			{
				// nr_node_hold(neg_node[i]);

				// nr_del_node_found(neg_node[i], neg_node[i]->routes[nr].via);

				nr = -1;
			}
		}
		// nr_node_put(neg_node[i]);
	}

#endif

	inp3_ltt_update (0, 1);
}

/* 22Sep2005, Maiko, I think this one is more or less finished
 *
void inp3_route_neg (struct nr_neigh *nr_neigh)
 *
 * 17Dec2005, Maiko, Function review - pending ! 
 */

void inp3_route_neg (struct nrnbr_tab *nr_neigh)
{
	struct nrroute_tab *nr_node, **neg_node;
	int chain, neg_nodes = 0;
	struct nr_bind *nrbp;

	neg_node = (struct nrroute_tab**)callocw (1,
		sizeof(struct nrroute_tab*) * MAX_RIPNEG);

	if (!neg_node)
		return;

	for (chain = 0; chain < NRNUMCHAINS; chain++)
	{
		nr_node = Nrroute_tab[chain];

		while (nr_node != NULL)
		{
			if ((nrbp = find_best (nr_node->routes, 0)) != NULLNRBIND)
			{
				if (nrbp->via == nr_neigh)
				{
					if (neg_nodes >= MAX_RIPNEG)
					{
						inp3_nodes_neg (neg_node, neg_nodes, nr_neigh);
						neg_nodes = 0;
					}

					// nr_node_hold(nr_node);

					neg_node[neg_nodes] = nr_node;

					neg_nodes++;
				}
			}

			nr_node = nr_node->next;
		}
	}

	if (neg_nodes)
	{
		inp3_nodes_neg (neg_node, neg_nodes, nr_neigh);
		neg_nodes = 0;
	}

	free (neg_node);

	return;
}

/* 23Sep2005, Added (1:43 am in the morning :-) - just need to
 * get the pullup () stuff converted from the skb data ptrs
 * 23Sep2005, finish this function up, put in logging ..
 *
 * 16Dec2005, Maiko, Function review - looks okay, BUT the nr_sort_node ()
 * still needs to be dealt with AND the PROC_NEG_NODE should be undef'd.
 */
int inp3_rif_rx (struct mbuf *bp, struct ax25_cb *ax25)
{
	char nodecall[AXALEN], tmp[AXBUF], tmp2[AXBUF], *tptr;
	struct nrroute_tab **neg_node, *nr_node = NULL;
	int neg_nodes = 0, hops = 0, tt = 0, qual = 0;
	struct nrnbr_tab *nr_neigh = NULL;
	unsigned char *dptr, mnemonic[7];
	int i, optlen, opttype, chain;
	struct nr_bind *nrbp, *nrbp2;

	int len;

	/* 05Nov2005, Maiko, Interesting - gdb shows we got a null ax25 */
	if (ax25 == NULL)
	{
		log (-1, "RIF null ax25");
		return 1;
	}

	/* incoming RIF - make sure we have neighbour on record */

	if ((nr_neigh = find_nrnbr (ax25->remote, ax25->iface)) == NULLNTAB)
	{
		log (-1, "RIF from [%s], but no neighbor route",
			pax25 (tmp, ax25->remote));

		return 1;
	}

	neg_node = (struct nrroute_tab**)callocw (1,
			sizeof(struct nrroute_tab*) * MAX_RIPNEG);

	if (!neg_node)
	{
		log (-1, "RIF no memory");
		return 1;
	}

	pullup (&bp, (char*)0, 1);	/* skip the signature */

	len = len_p (bp);

	/* continue until end of packet */
	while (len > 0)
	{
		mnemonic[0] = 0;
		pullup (&bp, nodecall, AXALEN);
		len -= AXALEN;

		hops = pullchar (&bp);
	/*
	 * Use 'pullchar' when dealing with unsigned char data. It will
	 * take the unsigned char, and return it in the integer. Using
	 * pullup brings it back as a signed char (default) which will
	 * mess up these types of calculations - Maiko, 23Sep2005.
	 * 
		pullup (&bp, tmp, 2);
		tt = (tmp[0] << 8) + tmp[1];
	 */
		tt = pullchar (&bp) << 8;
		tt = tt + pullchar (&bp);

		len -=3;	/* account for the hops and tt values just pulled */

#ifndef	WATCH_FOR_GARBAGE
		/*
		 * 05Nov05, Maiko, Garbage info seems to come in
		 * sometimes - I don't know why yet, but it's not
		 * good data to work with - should be ignored !
		 */

 		pax25 (tmp2, nodecall);
		for (i = 0, tptr = tmp2; *tptr; tptr++)
		{
			if (!isprint (*tptr))
			{
				*tptr = '?';
				i++;
			}
		}
#endif

		if (Nr_debug)
		{
			log (-1, "From [%s] RIF [%s] hops %d tt %d",
				pax25 (tmp, ax25->remote), tmp2, hops, tt);
		}

		/*
		 * Now be carefull here !!! The next byte tells us if this is the
		 * end of the RIF record (0x00 means EOP), or if additional options
		 * are being passed (like aliase or ip stuff).
		 */

		if ((optlen = pullchar (&bp)) != -1)
		{
			len--;

			/* if this is EOP, that's it - it's been pulled already !!! */

			/* Function review - BETTER CHECK THIS !!! Wonder if this
			 * is the source of the garbage, since an offset can do it.
			 */

			if (optlen != 0x00)
			{
				/* if not, then process the option (most likely aliase) */

				if ((opttype = pullchar (&bp)) != -1)
				{
					len--;

					if (opttype == 0x00)
					{
						if (optlen - 2 > 6)
							optlen = 8;

						pullup (&bp, mnemonic, optlen - 2);
						mnemonic[optlen - 2] = 0;
						len -= (optlen - 2);

						if (Nr_debug && i == 0)
							log (-1, "alias [%s]", mnemonic);
					}
				}

				pullup (&bp, (char*)0, 1);	/* skip the EOP character */
				len--;
			}
		}

#ifndef	WATCH_FOR_GARBAGE
		/* 05Nov05, Maiko, Safe guard against junk entries */
		if (i)
		{
			if (Nr_debug)
				log (-1, "garbage entry");

			continue;
		}
#endif
		/*
		 * I get it now, neighbour is only marked full INP3 when I get
		 * a RIF frame from them. Makes sense !
		 */
		nr_neigh->inp_state = NR_INP_STATE_INP;

		/* Over the horizon? */
		if (tt + nr_neigh->rtt > TT_HORIZON || hops == 255)
			tt = TT_HORIZON;

		qual = rtt2qual (nr_neigh->rtt + tt, hops);

		/*
		 * September 30, 2005 - Difference between the linux kernel version
		 * and my version of how RIF records are recorded and processed !
		 *
		 * The linux kernel version (PE1RXQ) does a nr_add_node at this point
		 * to make sure the node exists, before it checks the routes. I think
		 * that's a bit too aggressive, and I don't see the point of doing it,
		 * when most likely it has been added already (or will be soon) from
		 * a netrom node broadcast from the neighbour that sent us the RIF.
		 *
		 * Sure they may be a delay on startup, but when things settle, the
		 * route table winds up getting filled with everyone anyways, and it's
		 * kinda neat to see the RIF traffic settle down, and most of it winds
		 * up updating the route table at that point anyways.
		 *
		 * I get quite a few RIF records for nodes that are 20 or more hops
		 * away (never mind 20, even 13 is pushing it). These nodes will not
		 * appear in any netrom broadcasts (I doubt they will), so even more
		 * reason to NOT add them at this stage. Their quality values would
		 * be awefull to begin with, so I really don't want to add them.
		 *
		 * We'll have to keep an eye on it and see how it works ...
		 *
		 * Your comments, suggestions, flames, whatever are all welcome !
		 *
		 */

		/* get node for this callsign - do next RIF if not found */
		if ((nr_node = find_nrroute (nodecall)) == NULLNRRTAB)
		{
			if (Nr_debug)
				log (-1, "not in the route table");

			continue;
		}

		/* 02Nov2005, Maiko, Replaces route arrays with find_bind !!! This
		 * function finds the route that binds node to current neighbour.
		 */
		if ((nrbp = find_bind (nr_node->routes, nr_neigh)) == NULLNRBIND)
		{
			if (Nr_debug)
				log (-1, "no routes");

			continue;
		}

		if (Nr_debug)
		{
			log (-1, "updating (old/new) tt %d/%d hops %d/%d quality %d/%d",
				nrbp->tt, tt, nrbp->hops, hops, nrbp->quality, qual);
		}

		nrbp->tt = tt;
		nrbp->hops = hops;
		nrbp->quality = qual;

	/* 23Sep2005, Maiko, Not sure how to deal with this sort right
	 * now, if we even need to, since NOS has slightly different ways
	 * to build the node lists (or does it) ???
	 *
	 * 16Dec2005, Maiko, Still not sure what nr_sort_node does ...
	 */
#ifdef	STILL_NEED_TO_DO_THIS
		/* Call nr_sort_node in case a better route is now known */
		nr_sort_node(nr_node);
		// nr_node_unlock(nr_node);
#endif
		/* Is it negative information?
		if ((i == 0 && infotype (nr_node->ltt, nr_node->routes[0].tt +
			nr_node->routes[0].via->rtt) == -1))
		*/
		/* 02Nov2005, Maiko, If this IS the best route to the
		 * neighbour, then check for negative information, I
		 * think that's what they intended in the code ...
		 */
		nrbp2 = find_best (nr_node->routes, 0);

		if (nrbp2 == nrbp && infotype (nr_node->ltt,
			nrbp2->tt + (nrbp2->via)->rtt) == -1)
		{
			if (neg_nodes >= MAX_RIPNEG)
			{
				inp3_nodes_neg (neg_node, neg_nodes, nr_neigh);
				neg_nodes = 0;
			}
			neg_node[neg_nodes] = nr_node;
			neg_nodes++;
			break;
		}

		/* If its positive information we don't propagate it yet. */
		// nr_node_put(nr_node);
	}

	if (neg_nodes)
	{
		inp3_nodes_neg (neg_node, neg_nodes, nr_neigh);
	}

	free (neg_node);

	return 0;
}

/* end of PE1RXQ code - added September 22, 2005 */

static char inp3_l3rtt_addr[AXALEN] = { 'L' << 1, '3' << 1, 'R' << 1, 'T' << 1, 'T' << 1, 0x40, 0 };

/* 15Sep2005, Maiko, Start on this function - WORKING ON IT !!!
 *
 * 17Sep2005, Maiko, Now on my home development machine, working on
 * just the _tx function, see if I can get a response from WSC xnet
 * box which I'm testing with
 *
 * 16Dec2005, Maiko, Function review - looks okay ! - BUT using Nralias
 * instead of a function called 'inp3_first_mnemonic' - investigate.
 */
int inp3_l3rtt_tx (struct nrnbr_tab *nr_neigh, struct iface *ifc)
{
	unsigned char *rtt_data;
	struct mbuf *hbp, *dbp;
	struct ax25_cb *axp;
	struct timezone tz;
	struct timeval tv;

	if ((hbp = alloc_mbuf (NR3NODEHL + L3RTT_MTU + 1)) == NULLBUF)
	{
		log (-1, "inp3_l3rtt_tx - no memory");
		return -1;
	}

	hbp->cnt = NR3NODEHL + L3RTT_MTU + 1;

	rtt_data = hbp->data;

	*rtt_data++ = 0xcf;	/* PID for NETROM */

	memset (rtt_data, 0x20, L3RTT_MTU);
	memcpy (rtt_data, Nr_iface->hwaddr, AXALEN);
	rtt_data += AXALEN;
	memcpy (rtt_data, inp3_l3rtt_addr, AXALEN);
	rtt_data += AXALEN;

	*rtt_data++ = 0x02; /* ttl */

	*rtt_data++ = 0x00;
	*rtt_data++ = 0x00;
	*rtt_data++ = 0x00;
	*rtt_data++ = 0x00;

	*rtt_data++ = NR_INFO;

	/* do_gettimeofday (&tv); */
	gettimeofday (&tv, &tz);

	/* Has to stay within L3RTT_MTU! */
	rtt_data += sprintf (rtt_data, "L3RTT: %10d %10d %10d %10d ",
		(int)tv.tv_sec, nr_neigh->rtt, nr_neigh->rtt, (int)tv.tv_usec);

	rtt_data += sprintf (rtt_data, "%-6s %11s %s $M%d $N", Nralias,
		"LEVEL3_V2.1", "LINUX" INPVERSION, TT_HORIZON);

	*rtt_data = 0x20;

	rtt_data[L3RTT_MTU] = 0x0d;

	/*
	 * Make sure there is a connection to the neighbor, and make
	 * sure we use our netrom interface call for the connection.
	 */
	if ((axp = find_ax25 (Nr_iface->hwaddr, nr_neigh->call, ifc)) == NULLAX25 ||
		(axp->state != LAPB_CONNECTED && axp->state != LAPB_RECOVERY))
	{
        /* Open a new connection or reinitialize old one */

		axp = open_ax25 (ifc, Nr_iface->hwaddr, nr_neigh->call, AX_ACTIVE,
			0, s_arcall, s_atcall, s_ascall, -1);

        if (axp == NULLAX25)
		{
			log (-1, "inp3_l3rtt_tx - open ax25 connection failed");
            free_p (hbp);
            return -1;
        }
	}
  
    send_ax25 (axp, hbp,-1);  /* pass it off to ax25 code */

	return 1;
}

/* 04Oct2005, Maiko (VE4KLM), function to send l3rtt */
int dol3rtt (int argc, char **argv, void *p)
{
	struct nrnbr_tab *nr_neigh;
	char remote[AXALEN];
	struct iface *ifp;

	setcall (remote, argv[1]);

	if ((ifp = if_lookup (argv[2])) == (struct iface*)0)
	{
		tputs ("no interface found");
		return 0;
	}

	if ((nr_neigh = find_nrnbr (remote, ifp)) == NULLNTAB)
	{
		tputs ("no neighbour found");
		return 0;
	}

	inp3_l3rtt_tx (nr_neigh, ifp);

	return 0;
}

/* 14Sep2005, Maiko, RIF functions - taken from PE1RXQ patch */

#define	MAX_RIP	15

/*
 * 14Sep2005, Created function skeleton, started to port to JNOS, this
 * one will be a bit challenging to complete ...
 * 19Sep2005, Okay, now we need this function done, since it's called
 * on any L3RTT coming in as a reply to our L3RTT request
 * 20Sep2005, Let's complete this !
 *
 * 16Dec2005, Maiko, Function review - looks okay now, revamped selection
 * of best route code AGAIN - BUT need to pick alternative route still.
 */
int inp3_rif_tx (struct nrnbr_tab *nr_neigh, int all)
{
	struct nrroute_tab *nr_node;
	int route, tt, hops, ripcount = 0;
	unsigned char *rip = NULL;
	struct mbuf *hbp, *dbp, *savehdr;
	struct nr_bind *nrbp;
	char destbuf[AXBUF];
	struct iface *ifp;
	int chain, len;

	if ((hbp = alloc_mbuf (2)) == NULLBUF)
		return -1;

	hbp->cnt = 2;

	hbp->data[0] = PID_NETROM;
	hbp->data[1] = NR3NODESIG;

	savehdr = copy_p (hbp, 2);

	if (all)
	{
		/* Send a RIP for each netrom interface we have */

		for (ifp = Ifaces; ifp; ifp = ifp->next)
		{
			if (ifp->flags & IS_NR_IFACE)
			{
				len = 12 + strlen (Nralias) + 1;	/* include EOP */

				if ((dbp = alloc_mbuf (len)) == NULLBUF)
					return -1;

				dbp->cnt = len;

				rip = dbp->data;

				memcpy (rip, ifp->hwaddr, AXALEN);
				rip += AXALEN;

				*rip++ = 1;	/* hops */
				*rip++ = 0;	/* tt */
				*rip++ = 0;	/* tt */

				*rip++ = strlen (Nralias) + 2;
				*rip++ = 0;

				strcpy (rip, Nralias);	/* NULL terminator is the EOP */

				append (&hbp, dbp);	/* append to chain */

				ripcount++;
			}
		}
	}

	for (chain = 0; chain < NRNUMCHAINS; chain++)
	{
		nr_node = Nrroute_tab[chain];

		while (nr_node != NULL)
		{
			/* first find the best route to this node */

			if ((nrbp = find_best (nr_node->routes, 0)) == NULLNRBIND)
			{
				nr_node = nr_node->next;
				continue;
			}

			/* if the best route is via the neighbour currently being RIF'd
			 * for, then pick the next best route instead (if there is one),
			 * or continue on to the next node entry in the table.
			 */
			if (nrbp->via == nr_neigh)
			{
	 			if (nr_node->num_routes > 1)
					log (-1, "inp3_rif_tx - TODO - pick alternate route");

				/* future else should be put here */
				nr_node = nr_node->next;
				continue;
			}

			if ((nrbp->via)->inp_state == NR_INP_STATE_INP)
			{
				hops = nrbp->hops;

				tt = nrbp->tt + (nrbp->via)->rtt;
			}
			else
			{
				hops = qual2hops (nrbp->quality);

				tt = qual2rtt (nrbp->quality);
			}

			if (Nr_debug)
			{
				log (-1, "call [%s] hops [%d] tt [%d]",
					pax25 (destbuf, nr_node->call), hops, tt);
			}

			if (hops + 1 < 256 && (infotype (nr_node->ltt, tt) || all))
			{
				strcpy (destbuf, nr_node->alias);

				len = 12 + strlen (destbuf) + 1;	/* include EOP */

				if ((dbp = alloc_mbuf (len)) == NULLBUF)
					return -1;

				dbp->cnt = len;

				rip = dbp->data;

				memcpy (rip, &nr_node->call, AXALEN);
				rip += AXALEN;

				*rip++ = hopsmin (hops) + 1;
				*rip++ = ttlimit (tt) / 256;
				*rip++ = ttlimit (tt) & 0xff;

				*rip++ = strlen (destbuf) + 2;
				*rip++ = 0;

				strcpy (rip, destbuf);	/* NULL terminator is the EOP */

				append (&hbp, dbp);	/* append to chain */

				ripcount++;
			}

			if (ripcount >= MAX_RIP)
			{
				rif_tx (nr_neigh, hbp);

				hbp = copy_p (savehdr, NR3NODEHL);

				ripcount = 0; 
			}

			nr_node = nr_node->next;
		}
	}

	if (ripcount)
		rif_tx (nr_neigh, hbp);
	else
		free_p (hbp);

	return 0;
}

#endif

