
/*
 * INP3 - Main calls, time to get actual daemons coded and running
 *
 * 28Sep2005, Maiko Langelaar, VE4KLM
 *
 */

#include "global.h"

#if defined (NETROM) && defined (INP3)

#include "ax25.h"
#include "netrom.h"
#include "iface.h"

#include "inp3.h"

static int l3rttcnt = 0, rifcount = 0;

/* 16Dec2005, Maiko, Function review - Looks okay ! */
static void inp3d_l3rtt (void)
{
	struct nrnbr_tab *nr_neigh;
	char tmp[AXBUF];
	int chain;

	if (Nr_debug)
		log (-1, "time to send L3RTT frames to our neighbours");

	for (chain = 0; chain < NRNUMCHAINS; chain++)
	{
		nr_neigh = Nrnbr_tab[chain];

		while (nr_neigh != NULL)
		{
			if (Nr_debug)
				log (-1, "L3RTT > [%s]", pax25 (tmp, nr_neigh->call));

			inp3_l3rtt_tx (nr_neigh, nr_neigh->iface);

			nr_neigh = nr_neigh->next;
		}
	}
}

/* 16Dec2005, Maiko, Function review - Looks okay ! */
static void inp3d_rif (void)
{
	struct nrnbr_tab *nr_neigh;
	char tmp[AXBUF];
	int chain;

	rifcount++;

	/*
	 * Send all changed routes to the nodes, then mark them
	 * changed. Also once in a while we send complete list.
	 */

	if (Nr_debug)
		log (-1, "checking if we need to send RIF frames");

	for (chain = 0; chain < NRNUMCHAINS; chain++)
	{
		nr_neigh = Nrnbr_tab[chain];

		while (nr_neigh != NULL)
		{
			if (Nr_debug)
			{
				log (-1, "neighbour [%s] state %d",
					pax25 (tmp, nr_neigh->call), nr_neigh->inp_state);
			}

			/* looks like their 'nr_neigh' maps to our 'nrnbr_tab' structure */
			if (nr_neigh->inp_state == NR_INP_STATE_INP)
			{
				if (rifcount >= RIF_INTERVAL)
					inp3_rif_tx (nr_neigh, 1);
				else
					inp3_rif_tx (nr_neigh, 0);
			}

			nr_neigh = nr_neigh->next;
		}
	}

	if (rifcount >= RIF_INTERVAL)
	{
		rifcount = 0;

		inp3_ltt_update (1, 0);
	}
	else inp3_ltt_update (0, 0);
}

/*
 * 16Dec2005, Maiko, Function review - Looks okay ! BUT we should have
 * a pwait () in the while loop incase we get a signal to kill thread.
 */
static void inp3d (int unused OPTIONAL, void *sp, void *p OPTIONAL)
{
	log (-1, "INP3 Scheduler started");

	while (1)
	{
		/* every 5 minutes I see an L3RTT from neighbour */
		if (++l3rttcnt > L3RTT_INTERVAL)
		{
			inp3d_l3rtt ();
			l3rttcnt = 0;
		}
	/*
	 * 05Nov05, Maiko, lets get other stuff working before we
	 * start sending RIF frames, and messing up other system.
	 */
		else inp3d_rif ();	/* see a full rif every 24 minutes */

		j2pause (60000);	/* that means THIS pause is for 1 minute */
	}
}

int inp3start (int argc, char **argv, void *p)
{
	newproc ("INP3 scheduler", 2048, inp3d, 0, 0, NULL, 0);
	return 0;
}

#endif

