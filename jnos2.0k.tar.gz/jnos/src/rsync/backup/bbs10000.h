#ifndef	_BBS10000_H
#define _BBS10000_H

typedef struct {
    char *name;
    char *pass;
} PASSINFO;

#endif
