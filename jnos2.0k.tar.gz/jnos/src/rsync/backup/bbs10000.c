
/*
 * Web Based BBS Access for JNOS 2.0g and beyond ...
 *
 * June 8, 2009 - started working in a play area on a work machine
 * July 3, 2009 - put into my official development source (prototype)
 *
 * Designed and written by VE4KLM, Maiko Langelaar
 *
 * For non-commercial use (Ham Radio) only !!!
 *
 */

#include "global.h"

#ifdef	HTTPVNC

#ifndef OPTIONAL
#define OPTIONAL
#endif

#include "ctype.h"
#include "cmdparse.h"
#include "commands.h"

#ifndef MSDOS
#include <time.h>
#endif

#include <sys/stat.h>
#include "mbuf.h"

#include "socket.h"

/* 01Feb2002, Maiko, DOS compile for JNOS will complain without this */
#ifdef  MSDOS
#include "internet.h"
#endif

#include "netuser.h"
#include "ip.h"
#include "files.h"
#include "session.h"
#include "iface.h"
#include "udp.h"
#include "mailbox.h"
#include "usock.h"
#include "mailutil.h"
#include "smtp.h"

#include "proc.h"

#include "bbs10000.h"	/* 03Jul2009, Maiko, New header file */

#define	MAXTPRINTF	(SOBUF - 5)

static int mbxs[2] = { -1, -1 };

#define ISCMDLEN 256

int escape_char = 0;
int clear_char = 0;

/* 06Jul09, Maiko, use readonly, that way it still appears in the URI */
static char *Sdisabled = "readonly";

static char *currcall = (char*)0;

static int mbxl = 0, mbxr = 0;

/* 25Jun2009, Brand new private httpget and parse functions */

static char* parse (char *hptr)
{
	char *ptr, *tptr;

	/* make a working copy of hptr, leave the original one intact */
	tptr = malloc (strlen(hptr));

	ptr = tptr;

	log (-1, "parse [%s]", hptr);

	while (*hptr && *hptr != '&' && *hptr != ' ')
	{
		/* Map '+' characters to spaces */

		if (*hptr == '+')
			*ptr = ' ';

		/* Map special (encodings) characters to real characters */

		else if (*hptr == '%')
		{
			hptr++;

			if (!memcmp (hptr, "25", 2))
				*ptr = '%';

			if (!memcmp (hptr, "2F", 2))
				*ptr = '/';

			if (!memcmp (hptr, "40", 2))
				*ptr = '@';

			if (!memcmp (hptr, "3F", 2))
				*ptr = '?';

			hptr++;
		}

		else
			*ptr = *hptr;

		hptr++;
		ptr++;
	}

	*ptr = 0;

	log (-1, "parse [%s]", tptr);

	return tptr;
}

static int httpget (int s, char **calldata, char **cmddata, char **passdata, char **hostdata)
{
	int retval = 0, err;
	char important_stuff[ISCMDLEN+1];
	char *ptr;
	struct mbuf *bp;

	*calldata = *passdata = *cmddata = (char*)0;	/* very important */

	*hostdata = (char*)0;	/* 05Jul09, Maiko, Host from HTTP header */

	while (1)
	{
		j2alarm (10000);
   		err = recvline (s, important_stuff, ISCMDLEN);
		j2alarm (0);

		if (err == -1)
		{
			log (s, "*** RECVLINE errno %d ***", errno);
			retval = -1;
			break;
		}

		rip (important_stuff);

		log (-1, "http (%d) [%s]", strlen (important_stuff), important_stuff);

		if (!strlen (important_stuff))
			break;

		if ((ptr = strstr (important_stuff, "Host: ")) != NULL)
			*hostdata = parse (ptr + 6);

		if (!memcmp (important_stuff, "GET /cmd", 8))
		{
			if (strstr (important_stuff, "escape=on"))
			{
				log (-1, "escape toggled");
				escape_char = 1;
			}
			else escape_char = 0;

			/* 06Jul09, Maiko, Ability to clear tmp file */
			if (strstr (important_stuff, "clear=on"))
			{
				log (-1, "clear toggled");
				clear_char = 1;
			}
			else clear_char = 0;

			if ((ptr = strstr (important_stuff, "call=")) != NULL)
				*calldata = parse (ptr + 5);

			if ((ptr = strstr (important_stuff, "pass=")) != NULL)
				*passdata = parse (ptr + 5);

			if ((ptr = strstr (important_stuff, "cmd=")) != NULL)
				*cmddata = parse (ptr + 4);

			/* if either is present, then treat it as a valid request */
			if (*calldata || *cmddata)
				retval = 1;
		}
		else if (!memcmp (important_stuff, "GET / ", 6))
				retval = 1;
	}

	return retval;
}

static void socketpairsend (int usock, char *buffer, int len)
{
	char *tptr = buffer;

	int cnt = len;

	while (cnt > 0)
	{
		usputc (usock, *tptr);
		tptr++;
		cnt--;
	}

	usflush (usock);
}

PASSINFO passinfo;	/* this needs to be a global, not on the stack */

#ifdef	DOTN_COMPILE

static int mbxsock = -1;

static void mbx_to_web (int dev, void *n1, void *n2)
{
	int c;

	FILE *fp = fopen ("/tmp/crap", APPEND_TEXT);

	if (fp == NULL)
		return;

	log (-1, "waiting for mailbox to come up");

     while (mbxsock == -1)
     {
            /*
             * We might be told to die nicely through an ALERT, note
             * that pause returns a zero after normal wait is over, but
             * will return a -1 for other exceptions (like ALERTS).
             */
        if (j2pause (1000) == -1)
        {
            log (-1, "mbx2web alerted - die nicely");
            return;
        }
    }

	log (-1, "mailbox should be up, record mbx output to file");

	while (1)
	{
		if ((c = recvchar (mbxsock)) == EOF)
			j2pause(100);
		else
			fputc (c, fp);
	}
}

#endif

static void launch_mbox (char *callsign, char *passwd)
{

	if (mbxl)
	{
		log (-1, "mailbox already launched");
		return;
	}

	if (j2socketpair (AF_LOCAL, SOCK_STREAM, 0, mbxs) == -1)
	{
		log (-1, "socketpair failed, errno %d", errno);
		return;
	}

	seteol (mbxs[0], "\n");
	seteol (mbxs[1], "\n");

	sockmode (mbxs[1], SOCK_ASCII);

	passinfo.name = currcall = j2strdup (callsign);
	passinfo.pass = j2strdup (passwd);

//	newproc ("MBX2WEB", 512, mbx_to_web, mbxs[0], (void*)0, (void*)0, 0);

	newproc ("WEB2MBX", 8192, mbx_incom, mbxs[1],
		(void*)WEB_LINK, (void*)&passinfo, 0);

//	j2pause(5000);		/* give mailbox time to come up */

//	mbxsock = mbxs[0];	/* tell the mbx2web handler he can read now */

	mbxl = 1;
}

void serv10000 (int s, void *unused OPTIONAL, void *p OPTIONAL)
{
	char *body, *ptr, *cmddata, *calldata, *passdata, *hostdata;
	int needed, len, resp;
	struct mbx *curmbx;
	FILE *fpco;

	log (s, "connect");

	close_s (Curproc->output);

	Curproc->output = s;

	while (1)
	{
		char cmd[80];

		resp = httpget (s, &calldata, &cmddata, &passdata, &hostdata);

		if (resp < 1)
			break;

		log (-1, "hostdata [%s]", hostdata);

		if (calldata && *calldata && passdata && *passdata)
		{
			log (-1, "call [%s] pass [%s]", calldata, passdata);

			launch_mbox (calldata, passdata);

			j2pause (2000);		/* give it time to come up */
		}

		if (cmddata && *cmddata)
		{
			log (s, "command [%s]", cmddata);
			sprintf (cmd, "%s\n", cmddata);
		}
		else if (escape_char)
		{
			log (s, "escape character");
			sprintf (cmd, "%c\n", '');
		}
		else if (clear_char)
		{
			log (s, "clear session file");
			*cmd = 0;
		}
		else *cmd = 0;

		/* let's see if the mailbox is really active */

		if (calldata && *calldata)
		{
			log (s, "looking for [%s]", calldata);

			for (curmbx=Mbox; curmbx; curmbx=curmbx->next)
				if (!stricmp (curmbx->name, calldata))
					break;
			if (!curmbx)
				log (-1, "not found !!!");
		}
		else curmbx = (struct mbx*)0;

		if (!curmbx)
			mbxl = mbxr = 0;
		else
		{
			if (!mbxr)
			{
				log (-1, "setting socket file");
				(curmbx->proc)->output = sockfopen ("/tmp/crap", APPEND_TEXT);
				if ((curmbx->proc)->output < 0)
					log (-1, "sockfopen (%d) failed", errno);
				mbxr = 1;
			}

			/* 06Jul09, Maiko, This should work to clear file */
			else if (clear_char)
			{
				struct usock *up;

			    if ((up = itop ((curmbx->proc)->output)) == NULLUSOCK)
					log (-1, "clear session page - no socket info");

				else if (ftruncate (fileno (up->cb.fp), 0))
					log (-1, "truncate session page, errno %d", errno);
			}
		}

		if (*cmd)
		{
			if (curmbx)
			{
				socketpairsend (mbxs[0], cmd, strlen (cmd));

				/*
				 * We should echo command to the file socket as well, but
				 * let's add some color to it too to identifiy the input.
				 */
				if (j2send ((curmbx->proc)->output, cmd, strlen (cmd), 0) < 0)
					log (-1, "unable to echo command, errno %d", errno);
			}

			j2pause(2000);	/* wait for mailbox to finish command */
		}

	len = 0;

	if (mbxr)
	{
		/* Now read in the generated text file, find length */
			
   		if ((fpco = fopen ("/tmp/crap", READ_TEXT)))
		{
   			fseek (fpco, 0, SEEK_END);
			len = ftell (fpco);
			rewind (fpco);

			/* leave file open for later - allocate memory first */

			log (s, "ftell says %d bytes", len);
		}
	}

	needed = len + 1200;		/* cmd response + standard form */

	log (s, "Body needed %d bytes", needed);

	if ((body = malloc (needed)) == (char*)0)
	{
		log (s, "No memory available");
		break;
	}

	ptr = body;

	ptr += sprintf (ptr, "<html>");

	ptr += sprintf (ptr, "<head><script type=\"text/javascript\">\nfunction scrollElementToEnd (element) {\nif (typeof element.scrollTop != 'undefined' &&\ntypeof element.scrollHeight != 'undefined') {\nelement.scrollTop = element.scrollHeight;\n}\n}\n</script></head>");

	ptr += sprintf (ptr, "<body bgcolor=\"beige\"><br>");

	/* 05Jul09, Maiko, Now get hostname from HTTP header as we should */
	ptr += sprintf (ptr, "<form action=\"http://%s/cmd\" method=\"get\">", hostdata);

/* "192.168.1.201:10000"); */

	ptr += sprintf (ptr, "<table bgcolor=\"#aaffee\" style=\"border: 1px solid black;\" cellspacing=\"0\" cellpadding=\"10\"><tr><td>call <input type=\"text\" style=\"text-align: center;\" name=\"call\" size=\"6\" value=\"%s\" %s>&nbsp;pass <input type=\"password\" style=\"text-align: center;\" name=\"pass\" size=\"6\" value=\"\" %s></td><td>command <input type=\"text\" name=\"cmd\" value=\"\" size=\"20\" maxlength=\"80\" %s></td><td><input type=\"submit\" value=\"Enter\">&nbsp;<input type=\"checkbox\" name=\"escape\"><font size=1>CTRL-T</font>&nbsp;<input type=\"checkbox\" name=\"clear\"><font size=1>Clear</font></td></tr></table></form><p>", currcall ? currcall : "", mbxr ? Sdisabled : "", mbxr ? Sdisabled : "", !mbxr ? Sdisabled : "");

	if (mbxr)
	{
		ptr += sprintf (ptr, "<form name=\"formName\"><textarea style=\"border: 1px solid black; padding: 10px;\" name=\"textAreaName\" readonly=\"readonly\" rows=24 cols=80>");

		if (fpco)
		{
			char inbuf[82];

			while (fgets (inbuf, 80, fpco))
				ptr += sprintf (ptr, "%s", inbuf);

			fclose (fpco);
		}

		ptr += sprintf (ptr, "</textarea><script>scrollElementToEnd(document.formName.textAreaName);</script></p></form>");
	}
	else
	{
		ptr += sprintf (ptr, "<h4>no active sessions - please login</h4>");
	}

	ptr += sprintf (ptr, "</body></html>\r\n");

	pwait (NULL);	/* give other processes a chance */

	len = ptr - body;

 	log (s, "Body length %d", len);

	/* write the HEADER record */
	tprintf ("HTTP/1.1 200 OK\r\n");
	tprintf ("Content-Length: %d\r\n", len);
	tprintf ("Content-Type: text/html\r\n");
	tprintf ("Server: NOSbbs 1.0\r\n");

	/* use a BLANK line to separate the BODY from the HEADER */
	tprintf ("\r\n");

	/* 01Aug2001, VE4KLM, Arrggg !!! - the tprintf call uses vsprintf
	 * which has a maximum buf size of SOBUF, which itself can vary
	 * depending on whether CONVERSE or POPSERVERS are defined. If
	 * we exceed SOBUF, TNOS is forcefully restarted !!! Sooooo...,
	 * we will have to tprintf the body in chunks of SOBUF or less.
	 *
	tprintf ("%s", body);
	 */

	ptr = body;

	while (len > 0)
	{
		pwait (NULL);	/* give other processes a chance */

		if (len < MAXTPRINTF)
		{
			tprintf ("%s", ptr);
			len = 0;
		}
		else
		{
			tprintf ("%.*s", MAXTPRINTF, ptr);
			len -= MAXTPRINTF;
			ptr += MAXTPRINTF;
		}
	}

	free (body);

		break;	/* break out !!! */
	}

	log (s, "disconnect");

	close_s (s);
}

/* Start up HTTP VNC server */
int httpvnc1 (int argc, char *argv[], void *p)
{
    int16 port;

    if(argc < 2)
       port = 10000;
    else
       port = atoi(argv[1]);

    return start_tcp (port, "HTTP VNC Server", serv10000, 4096);
}

/* Stop the HTTP VNC server */
int httpvnc0 (int argc, char *argv[], void *p)
{
    int16 port;

    if(argc < 2)
       port = 10000;
    else
       port = atoi(argv[1]);

    return stop_tcp(port);
}

#endif	/* end of HTTPVNC */
