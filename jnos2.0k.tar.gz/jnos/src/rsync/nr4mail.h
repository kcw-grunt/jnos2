int nr40 __ARGS((int argc,char *argv[],void *p));
int nr4start __ARGS((int argc,char *argv[],void *p));
int dombnetrom __ARGS((int argc,char *argv[],void *p));
