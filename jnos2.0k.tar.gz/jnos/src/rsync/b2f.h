#ifndef	_B2F_H
#define _B2F_H

extern int j2noB2F (char*);

extern void j2AddnoB2F (char*);

#endif
